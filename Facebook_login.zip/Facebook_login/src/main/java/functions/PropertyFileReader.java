package functions;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertyFileReader {
    public String getProperty(String key) throws IOException {
        Properties pr = new Properties();

        //read property file using inputstream

        FileInputStream input = new FileInputStream("C:\\Users\\avees\\OneDrive\\Desktop\\Facebook Login Page\\Facebook_login\\src\\main\\resources\\facebook.properties");
        pr.load(input);
        return pr.getProperty(key);


    }
}

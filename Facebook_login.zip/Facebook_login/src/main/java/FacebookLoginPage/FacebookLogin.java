package FacebookLoginPage;

import functions.PropertyFileReader;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.Duration;

public class FacebookLogin {
    private static WebDriver driver;
    static PropertyFileReader pr = new PropertyFileReader();
    @Test
    public static void login() throws IOException {
        //Get email and password from property Files
        String email = pr.getProperty("email");
        String password = pr.getProperty("password");

        //Setup Driver
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.get("https://web.facebook.com/login/?_rdc=1&_rdr");
        //Type email
        WebElement userN = driver.findElement(By.id("email"));
        userN.sendKeys(email);
        //type passworD
        WebElement passN = driver.findElement(By.id("pass"));
        passN.sendKeys(password);
        //click lOgin button
        WebElement login = driver.findElement(By.id("loginbutton"));
        login.click();
        //Assert Title
        //Verify the facebook page loads using below assert function
        String actualTitle = driver.getTitle();
        String expectedTitle = "Facebook";
        Assert.assertEquals(actualTitle,expectedTitle, "Title Wrong");
        System.out.println(driver.getTitle());
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
        driver.close();
    }}
